from django.contrib import admin
from .models import sucursales

# Register your models here.
admin.site.register(sucursales)