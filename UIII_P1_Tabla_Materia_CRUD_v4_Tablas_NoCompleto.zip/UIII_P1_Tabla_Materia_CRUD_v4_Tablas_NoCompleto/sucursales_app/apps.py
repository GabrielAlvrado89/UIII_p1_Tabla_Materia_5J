from django.apps import AppConfig

class SucursalesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sucursales_app'
