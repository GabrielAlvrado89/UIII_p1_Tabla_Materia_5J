from django.urls import path
from ventas_app import views 

urlpatterns = [
    path("venta", views.inicio_ventas, name="venta"),
    path("registrarVentas/",views.registrarSucursal,name="registrarSucursal"),
    path('seleccionarVentas/<id_sucursal>', views.seleccionarSucursal, name='seleccionarSucursal'),
    path('editarVentas/', views.editarSucursal, name='editarMateria'),
    path('borrarVentas/<id_sucursal>', views.borrarSucursal, name='borrarSucursal' ),
]