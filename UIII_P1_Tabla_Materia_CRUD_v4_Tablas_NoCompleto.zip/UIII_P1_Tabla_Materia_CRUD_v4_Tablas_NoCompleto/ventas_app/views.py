from django.shortcuts import render,redirect
from .models import ventas
# Create your views here.
def inicio_ventas(request):
    venta=ventas.objects.all()
    return  render(request,"gestionarventas.html",{"misventas":venta})

def registrarVentas(request):
    id_venta=request.POST["txtidventa"]
    Cantidad=request.POST["txtCantidad"]
    Hora_venta=request.POST["txtHoraVenta"]

    guardarVentas=ventas.objects.create(
    id_venta=id_venta, Cantidad=Cantidad, Hora_venta=Hora_venta)
    return redirect("venta")

def seleccionarVentas(request, id_venta):
    venta = ventas.objects.get(id_venta=id_venta)
    return render(request,'editarventas.html', {'misventas': venta})


def editarVentas(request):
    id_venta=request.POST["txtidventa"]
    Cantidad=request.POST["txtCantidad"]
    Hora_venta=request.POST["txtHoraVenta"]
    venta = ventas.objects.get(id_venta=id_venta)
    venta.id_venta = id_venta
    venta.Cantidad = Cantidad
    venta.Hora_venta = Hora_venta
    venta.save() # guarda registro actualizado
    return redirect("venta")


def borrarVentas(request, id_venta):
    venta = ventas.objects.get(id_venta=id_venta)
    venta.delete() # borra el registro
    return redirect("venta")
