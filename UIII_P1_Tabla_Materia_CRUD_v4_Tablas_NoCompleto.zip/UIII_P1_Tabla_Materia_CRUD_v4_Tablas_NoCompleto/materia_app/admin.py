from django.contrib import admin
from .models import Materia
# Register your models here.

admin.site.register(Materia)