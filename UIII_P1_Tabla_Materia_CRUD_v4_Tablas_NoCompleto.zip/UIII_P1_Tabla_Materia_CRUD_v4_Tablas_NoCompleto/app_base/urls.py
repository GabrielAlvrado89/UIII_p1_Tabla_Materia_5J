from django.urls import path
from app_base import views 

urlpatterns = [
    #inicio papeleria
    path("", views.inicio, name="inicio"),
]