from django.contrib import admin
from .models import marcas

# Register your models here.
admin.site.register(marcas)