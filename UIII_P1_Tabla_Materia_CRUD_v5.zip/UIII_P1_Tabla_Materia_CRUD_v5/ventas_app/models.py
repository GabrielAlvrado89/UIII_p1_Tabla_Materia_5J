from django.db import models

class ventas(models.Model):
    id_venta=models.IntegerField()
    Cantidad=models.CharField(max_length=100)
    Hora_venta=models.CharField(max_length=4)
    
    def __str__(self):
        return self.nombre
