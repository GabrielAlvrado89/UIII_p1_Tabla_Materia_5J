from django.shortcuts import render,redirect
from .models import Proveedores
# Create your views here.
def inicio_Proveedor(request):
    proveedor=Proveedores.objects.all()
    return render(request,"gestionarproveedores.html",{"misproveedores": proveedor})

def registrarProveedor(request):
    id_proveedores=request.POST["txtidproveedor"]
    Producto=request.POST["txtproducto"]
    Cantidad=request.POST["txtcantidad"]

    guardarProveedor=Proveedores.objects.create(
    id_proveedores=id_proveedores, Producto=Producto ,Cantidad=Cantidad)
    return redirect("proveedor")

def seleccionarProveedor(request, id_proveedores):
    proveedor = Proveedores.objects.get(id_proveedores=id_proveedores)
    return render(request,'editarproveedores.html', {"misproveedores": proveedor})

def editarProveedor(request):
    id_proveedores=request.POST["txtidproveedor"]
    Producto=request.POST["txtproducto"]
    Cantidad=request.POST["txtcantidad"]
    proveedor = Proveedores.objects.get(id_proveedores=id_proveedores)
    proveedor.id_proveedores = id_proveedores
    proveedor.producto = Producto
    proveedor.Cantidad = Cantidad
    proveedor.save() # guarda registro actualizado
    return redirect("proveedor")


def borrarProveedor(request, id_proveedores):
    proveedor = Proveedores.objects.get(id_proveedores=id_proveedores)
    proveedor.delete() # borra el registro
    return redirect("proveedor")
