from django.contrib import admin
from .models import clientes

# Register your models here.
admin.site.register(clientes)