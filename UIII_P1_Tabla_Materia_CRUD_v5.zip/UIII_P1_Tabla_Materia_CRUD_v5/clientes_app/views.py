from django.shortcuts import render,redirect
from .models import clientes
# Create your views here.
def inicio_clientes(request):
    cliente=clientes.objects.all()
    return  render(request,"gestionarclientes.html",{"misclientes":cliente})

def registrarClientes(request):
    id_cliente=request.POST["txtidcliente"]
    Correo=request.POST["txtCorreo"]
    Domicilio=request.POST["txtDomicilio"]

    guardarVentas=clientes.objects.create(
    id_cliente=id_cliente, Correo=Correo, Domicilio=Domicilio)
    return redirect("cliente")

def seleccionarClientes(request, id_cliente):
    cliente = clientes.objects.get(id_cliente=id_cliente)
    return render(request,'editarcliente.html', {'misclientes': cliente})


def editarClientes(request):
    id_cliente=request.POST["txtidcliente"]
    Correo=request.POST["txtCorreo"]
    Domicilio=request.POST["txtDomicilio"]
    cliente = clientes.objects.get(id_cliente=id_cliente)
    cliente.id_cliente = id_cliente
    cliente.Correo = Correo
    cliente.Domicilio = Domicilio
    cliente.save() # guarda registro actualizado
    return redirect("cliente")


def borrarClientes(request, id_cliente):
    cliente = clientes.objects.get(id_cliente=id_cliente)
    cliente.delete() # borra el registro
    return redirect("cliente")
