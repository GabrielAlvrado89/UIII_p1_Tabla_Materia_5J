from django.db import models

class Productos(models.Model):
    id_producto=models.IntegerField()
    Cantidad=models.CharField(max_length=100)
    NombreProducto=models.CharField(max_length=100)
    
    def __str__(self):
        return self.nombre