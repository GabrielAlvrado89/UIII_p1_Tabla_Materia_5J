from django.shortcuts import render,redirect
from .models import Productos
# Create your views here.
def inicio_Producto(request):
    producto=Productos.objects.all()
    return render(request,"gestionarproducto.html",{"misproductos": producto})

def registrarProducto(request):
    id_producto=request.POST["txtidproducto"]
    Cantidad=request.POST["txtcantidad"]
    NombreProducto=request.POST["txtnombreproducto"]

    guardarProducto=Productos.objects.create(
    id_producto=id_producto, Cantidad=Cantidad, NombreProducto=NombreProducto)
    return redirect("producto")

def seleccionarProducto(request, id_producto):
    producto = Productos.objects.get(id_producto=id_producto)
    return render(request,'editarproducto.html', {'misproductos': producto})

def editarProducto(request):
    id_producto=request.POST["txtidproducto"]
    Cantidad=request.POST["txtcantidad"]
    NombreProducto=request.POST["txtnombreproducto"]
    producto = Productos.objects.get(id_producto=id_producto)
    producto.id_producto = id_producto
    producto.Cantidad = Cantidad
    producto.NombreProducto = NombreProducto
    producto.save() # guarda registro actualizado
    return redirect("producto")


def borrarProducto(request, id_producto):
    producto = Productos.objects.get(id_producto=id_producto)
    producto.delete() # borra el registro
    return redirect("producto")
